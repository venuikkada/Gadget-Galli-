// Gadget Galli Shop Partner app: settings for this website.
// Edit the values in quotes and save. The website picks them up on the next page load; no rebuild needed.
window.GG_CONFIG = {
  // Supabase → Project Settings → API: the "Project URL" and the "anon public" key
  supabaseUrl: "https://lykspiuhimplqtcsjgpm.supabase.co",
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx5a3NwaXVoaW1wbHF0Y3NqZ3BtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE3NzMzMDksImV4cCI6MjEwNzM0OTMwOX0.VV8eTT92rmUnytiZHKFwLJtuZiyRRBpt8OqMxluE8ck",

  // Your three website addresses, starting with https:// and without a slash at the end
  customerAppUrl: "https://darkslategray-dugong-202922.hostingersite.com",
  partnerAppUrl: "https://aliceblue-hedgehog-131163.hostingersite.com",
  adminUrl: "https://darksalmon-louse-742432.hostingersite.com",

  // Maps. Empty uses OpenStreetMap's free tiles, fine while traffic is small. When the apps get busy, sign up
  // for a free map-tile key (for example MapTiler) and paste its tile address and credit line here.
  mapTileUrl: "",
  mapAttribution: "",

  // Which app this website shows. Leave it as it is.
  app: "partner",
  // true shows the demo phone numbers on the login screen. Set it to false for a real launch.
  demo: true,
};
